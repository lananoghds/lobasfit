import React from 'react'

// Elemento de assinatura visual do URSA: uma marca de garra estilizada.
// Usado com moderação em poucos pontos-chave (não em toda tela).
export function ClawMark({ className = '', style }) {
  return (
    <svg
      className={className}
      style={style}
      width="72"
      height="72"
      viewBox="0 0 72 72"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <line x1="18" y1="8" x2="26" y2="64" stroke="url(#clawGrad)" strokeWidth="7" strokeLinecap="round" />
      <line x1="36" y1="4" x2="40" y2="66" stroke="url(#clawGrad)" strokeWidth="7" strokeLinecap="round" />
      <line x1="54" y1="8" x2="46" y2="64" stroke="url(#clawGrad)" strokeWidth="7" strokeLinecap="round" />
      <defs>
        <linearGradient id="clawGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f0304c" />
          <stop offset="1" stopColor="#8c0f26" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  )
}

export function PawMark({ size = 22, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} aria-hidden="true">
      <ellipse cx="12" cy="15" rx="6" ry="5" />
      <ellipse cx="5.6" cy="9.2" rx="2.4" ry="3.1" transform="rotate(-18 5.6 9.2)" />
      <ellipse cx="9.6" cy="6.4" rx="2.4" ry="3.2" transform="rotate(-6 9.6 6.4)" />
      <ellipse cx="14.4" cy="6.4" rx="2.4" ry="3.2" transform="rotate(6 14.4 6.4)" />
      <ellipse cx="18.4" cy="9.2" rx="2.4" ry="3.1" transform="rotate(18 18.4 9.2)" />
    </svg>
  )
}

export default ClawMark
