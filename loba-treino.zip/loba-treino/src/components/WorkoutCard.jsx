import React from 'react'

export default function WorkoutCard({ workout, onClick }) {
  const count = workout.exercises.length
  return (
    <button className="workout-card" onClick={onClick}>
      <span className="workout-card__bar" />
      <span className="workout-card__emoji">{workout.emoji}</span>
      <div>
        <div className="workout-card__name">{workout.name}</div>
        <div className="workout-card__count">
          {count > 0 ? `${count} exercícios` : 'Sem ficha detalhada'}
        </div>
      </div>
    </button>
  )
}
