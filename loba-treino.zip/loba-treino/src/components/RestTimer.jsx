import React, { useEffect, useRef, useState } from 'react'
import { formatSeconds } from '../lib/format'

export default function RestTimer({ duration, nextLabel, onDone }) {
  const [remaining, setRemaining] = useState(duration)
  const [paused, setPaused] = useState(false)
  const intervalRef = useRef(null)
  const finishedRef = useRef(false)

  useEffect(() => {
    setRemaining(duration)
    finishedRef.current = false
  }, [duration])

  useEffect(() => {
    if (paused) return
    intervalRef.current = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(intervalRef.current)
          if (!finishedRef.current) {
            finishedRef.current = true
            if (navigator.vibrate) navigator.vibrate([200, 100, 200])
            setTimeout(onDone, 500)
          }
          return 0
        }
        return r - 1
      })
    }, 1000)
    return () => clearInterval(intervalRef.current)
  }, [paused, onDone])

  const pct = duration > 0 ? (duration - remaining) / duration : 1
  const radius = 100
  const circumference = 2 * Math.PI * radius

  return (
    <div className="rest-overlay">
      <div className="rest-overlay__label">Descanso</div>
      <div className="rest-overlay__ring">
        <svg width="220" height="220" viewBox="0 0 220 220">
          <circle cx="110" cy="110" r={radius} fill="none" stroke="#222224" strokeWidth="10" />
          <circle
            cx="110"
            cy="110"
            r={radius}
            fill="none"
            stroke="#e8203f"
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference * (1 - pct)}
            transform="rotate(-90 110 110)"
            style={{ transition: 'stroke-dashoffset 1s linear' }}
          />
        </svg>
        <div className="rest-overlay__time" style={{ position: 'absolute' }}>
          {formatSeconds(remaining)}
        </div>
      </div>
      {nextLabel && <div className="rest-overlay__next">A seguir: {nextLabel}</div>}
      <div className="rest-overlay__actions">
        <button className="rest-overlay__btn" onClick={() => setPaused((p) => !p)}>
          {paused ? '▶ Continuar' : '⏸ Pausar'}
        </button>
        <button className="rest-overlay__btn" onClick={() => setRemaining(duration)}>
          ↻ Reiniciar
        </button>
        <button className="rest-overlay__btn rest-overlay__btn--primary" onClick={onDone}>
          Pular »
        </button>
      </div>
    </div>
  )
}
