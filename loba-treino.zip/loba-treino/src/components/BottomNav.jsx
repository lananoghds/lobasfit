import React from 'react'
import { useApp } from '../context/AppContext'

function HomeIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 11.5 12 4l9 7.5" />
      <path d="M5 10v9a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1v-9" />
    </svg>
  )
}

function DumbbellIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6.5 6.5 3 3M17.5 17.5 21 21" />
      <path d="m17 4 3 3-9 9-3-3z" />
      <path d="m14 7-2-2" />
      <path d="m20 10 2-2" />
      <path d="M7 20 4 17l9-9 3 3z" />
      <path d="m10 17 2 2" />
      <path d="m4 14-2 2" />
    </svg>
  )
}

function HistoryIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 1 0 3-6.7" />
      <path d="M3 4v4h4" />
      <path d="M12 8v4l3 2" />
    </svg>
  )
}

function ProgressIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 3v18h18" />
      <path d="M7 15v3M12 10v8M17 6v12" />
    </svg>
  )
}

const ITEMS = [
  { screen: 'home', label: 'Início', Icon: HomeIcon },
  { screen: 'workouts', label: 'Treinos', Icon: DumbbellIcon },
  { screen: 'history', label: 'Histórico', Icon: HistoryIcon },
  { screen: 'progress', label: 'Progresso', Icon: ProgressIcon },
]

export default function BottomNav() {
  const { view, navigate } = useApp()

  return (
    <nav className="bottom-nav">
      <div className="bottom-nav__inner">
        {ITEMS.map(({ screen, label, Icon }) => {
          const active = view.screen === screen
          return (
            <button
              key={screen}
              className={`bottom-nav__item ${active ? 'bottom-nav__item--active' : ''}`}
              onClick={() => navigate(screen)}
              aria-current={active ? 'page' : undefined}
            >
              <Icon />
              <span>{label}</span>
              <span className="bottom-nav__dot" />
            </button>
          )
        })}
      </div>
    </nav>
  )
}
