import React from 'react'
import { useApp } from '../context/AppContext'

function SeriesRow({ unitKey, seriesIndex, serie, onToggle }) {
  const { updateSeries, lastWeightFor } = useApp()
  const last = lastWeightFor(unitKey)

  return (
    <div className="series-row">
      <button
        className={`series-row__check ${serie.completed ? 'series-row__check--done' : ''}`}
        onClick={() => onToggle(unitKey, seriesIndex, serie)}
        aria-label={serie.completed ? 'Série concluída' : 'Marcar série como concluída'}
      >
        ✓
      </button>
      <span className="series-row__label">Série {seriesIndex + 1}</span>
      <div className="series-row__weight">
        {last && !serie.weight && <span className="series-row__last">Última vez: {last} kg ·</span>}
        <input
          inputMode="decimal"
          type="text"
          placeholder={last ? String(last) : '0'}
          value={serie.weight}
          onChange={(e) => updateSeries(unitKey, seriesIndex, { weight: e.target.value })}
        />
        <span>kg</span>
      </div>
    </div>
  )
}

function UnitBlock({ unit, onToggleSeries }) {
  const { updateSeries } = useApp()
  return (
    <div className="series-list">
      {unit.series.map((serie, i) => (
        <SeriesRow
          key={i}
          unitKey={unit.key}
          seriesIndex={i}
          serie={serie}
          onToggle={(key, idx, s) => onToggleSeries(key, idx, s, updateSeries)}
        />
      ))}
    </div>
  )
}

export default function ExerciseCard({ exercise, index, unitFor, onSeriesCompleted }) {
  const mainUnit = unitFor(exercise.id)
  const comboUnit = exercise.combo ? unitFor(`${exercise.id}-combo`) : null

  function handleToggle(unitKey, seriesIndex, serie, updateSeries) {
    const nextCompleted = !serie.completed
    updateSeries(unitKey, seriesIndex, { completed: nextCompleted })
    if (nextCompleted) onSeriesCompleted?.()
  }

  return (
    <div className="exercise-card">
      <div className="exercise-card__num">{String(index + 1).padStart(2, '0')}</div>
      <div className="exercise-card__name">{exercise.name}</div>
      <div className="exercise-card__scheme">
        {exercise.sets}x{exercise.reps}
      </div>

      {mainUnit && <UnitBlock unit={mainUnit} onToggleSeries={handleToggle} />}

      {exercise.combo && (
        <>
          <div className="exercise-card__combo-label">+ {exercise.combo.name} · {exercise.combo.sets}x{exercise.combo.reps}</div>
          {comboUnit && <UnitBlock unit={comboUnit} onToggleSeries={handleToggle} />}
        </>
      )}
    </div>
  )
}
