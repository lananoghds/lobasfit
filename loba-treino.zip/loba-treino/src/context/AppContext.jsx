import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react'
import { getWorkoutById } from '../data/workouts'
import {
  getHistory,
  saveHistoryEntry,
  getActiveSession,
  saveActiveSession,
  clearActiveSession,
  getLastWeightFor,
} from '../lib/storage'

const AppContext = createContext(null)

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp precisa estar dentro de <AppProvider>')
  return ctx
}

function buildSessionUnits(workout) {
  const units = []
  for (const ex of workout.exercises) {
    units.push({
      key: ex.id,
      label: ex.name,
      sets: ex.sets,
      reps: ex.reps,
      series: Array.from({ length: ex.sets }, () => ({ completed: false, weight: '' })),
    })
    if (ex.combo) {
      units.push({
        key: `${ex.id}-combo`,
        label: ex.combo.name,
        sets: ex.combo.sets,
        reps: ex.combo.reps,
        series: Array.from({ length: ex.combo.sets }, () => ({ completed: false, weight: '' })),
        isCombo: true,
        parentLabel: ex.name,
      })
    }
  }
  return units
}

export function AppProvider({ children }) {
  const [view, setView] = useState({ screen: 'home' })
  const [history, setHistory] = useState(() => getHistory())
  const [session, setSession] = useState(() => getActiveSession())

  const navigate = useCallback((screen, params = {}) => {
    setView({ screen, ...params })
    window.scrollTo(0, 0)
  }, [])

  const refreshHistory = useCallback(() => setHistory(getHistory()), [])

  const startWorkout = useCallback(
    (workoutId) => {
      const workout = getWorkoutById(workoutId)
      if (!workout) return
      const newSession = {
        workoutId,
        startedAt: Date.now(),
        units: buildSessionUnits(workout),
      }
      setSession(newSession)
      saveActiveSession(newSession)
      navigate('workout', { workoutId })
    },
    [navigate]
  )

  const updateSeries = useCallback((unitKey, seriesIndex, patch) => {
    setSession((prev) => {
      if (!prev) return prev
      const next = {
        ...prev,
        units: prev.units.map((u) =>
          u.key !== unitKey
            ? u
            : {
                ...u,
                series: u.series.map((s, i) => (i === seriesIndex ? { ...s, ...patch } : s)),
              }
        ),
      }
      saveActiveSession(next)
      return next
    })
  }, [])

  const finishWorkout = useCallback(() => {
    if (!session) return null
    const workout = getWorkoutById(session.workoutId)
    const durationMs = Date.now() - session.startedAt
    const exercisesDone = session.units.filter((u) => u.series.some((s) => s.completed))
    const seriesConcluidas = session.units.reduce(
      (acc, u) => acc + u.series.filter((s) => s.completed).length,
      0
    )
    const entry = {
      date: new Date().toISOString(),
      workoutId: session.workoutId,
      workoutName: workout?.name ?? session.workoutId,
      emoji: workout?.emoji ?? '🏋️',
      durationMs,
      seriesConcluidas,
      exercises: session.units.map((u) => ({
        key: u.key,
        label: u.label,
        series: u.series,
      })),
    }
    saveHistoryEntry(entry)
    refreshHistory()
    clearActiveSession()
    setSession(null)
    return { entry, exercisesDone }
  }, [session, refreshHistory])

  const discardSession = useCallback(() => {
    clearActiveSession()
    setSession(null)
  }, [])

  const lastWeightFor = useCallback((key) => getLastWeightFor(key), [])

  const value = useMemo(
    () => ({
      view,
      navigate,
      history,
      refreshHistory,
      session,
      startWorkout,
      updateSeries,
      finishWorkout,
      discardSession,
      lastWeightFor,
    }),
    [view, navigate, history, refreshHistory, session, startWorkout, updateSeries, finishWorkout, discardSession, lastWeightFor]
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
