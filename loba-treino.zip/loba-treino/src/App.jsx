import React from 'react'
import { AppProvider, useApp } from './context/AppContext'
import BottomNav from './components/BottomNav'
import Home from './screens/Home'
import WorkoutsList from './screens/WorkoutsList'
import WorkoutDetail from './screens/WorkoutDetail'
import FocusMode from './screens/FocusMode'
import Completed from './screens/Completed'
import History from './screens/History'
import Progress from './screens/Progress'

const SCREENS_WITHOUT_NAV = new Set(['workout', 'focus', 'completed'])

function Router() {
  const { view } = useApp()
  const showNav = !SCREENS_WITHOUT_NAV.has(view.screen)

  let content = null
  switch (view.screen) {
    case 'home':
      content = <Home />
      break
    case 'workouts':
      content = <WorkoutsList />
      break
    case 'workout':
      content = <WorkoutDetail workoutId={view.workoutId} />
      break
    case 'focus':
      content = <FocusMode workoutId={view.workoutId} />
      break
    case 'completed':
      content = <Completed />
      break
    case 'history':
      content = <History />
      break
    case 'progress':
      content = <Progress />
      break
    default:
      content = <Home />
  }

  return (
    <div className="app-shell">
      {content}
      {showNav && <BottomNav />}
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  )
}
