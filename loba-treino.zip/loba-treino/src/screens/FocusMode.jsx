import React, { useEffect, useMemo, useState } from 'react'
import { getWorkoutById } from '../data/workouts'
import { useApp } from '../context/AppContext'
import RestTimer from '../components/RestTimer'

function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 6l12 12M18 6 6 18" />
    </svg>
  )
}

function buildSteps(session) {
  const steps = []
  for (const unit of session.units) {
    unit.series.forEach((serie, i) => {
      steps.push({
        unitKey: unit.key,
        seriesIndex: i,
        label: unit.label,
        reps: unit.reps,
        parentLabel: unit.isCombo ? unit.parentLabel : null,
        totalInUnit: unit.series.length,
        indexInUnit: i,
        completed: serie.completed,
        weight: serie.weight,
      })
    })
  }
  return steps
}

export default function FocusMode({ workoutId }) {
  const { session, updateSeries, navigate, finishWorkout } = useApp()
  const workout = getWorkoutById(workoutId)
  const [resting, setResting] = useState(false)

  const steps = useMemo(() => (session ? buildSteps(session) : []), [session])

  const initialIndex = useMemo(() => {
    const idx = steps.findIndex((s) => !s.completed)
    return idx === -1 ? Math.max(steps.length - 1, 0) : idx
  }, [steps.length]) // eslint-disable-line react-hooks/exhaustive-deps

  const [currentIndex, setCurrentIndex] = useState(initialIndex)

  useEffect(() => {
    setCurrentIndex(initialIndex)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workoutId])

  if (!session || session.workoutId !== workoutId || steps.length === 0) return null

  const step = steps[Math.min(currentIndex, steps.length - 1)]
  const allDone = steps.every((s) => s.completed)

  function handleComplete() {
    updateSeries(step.unitKey, step.seriesIndex, { completed: true })
    if (currentIndex < steps.length - 1) {
      setResting(true)
    } else {
      setTimeout(() => {
        finishWorkout()
        navigate('completed', { workoutId })
      }, 300)
    }
  }

  function handleRestDone() {
    setResting(false)
    setCurrentIndex((i) => Math.min(i + 1, steps.length - 1))
  }

  function goPrev() {
    setCurrentIndex((i) => Math.max(i - 1, 0))
  }

  function goNext() {
    setCurrentIndex((i) => Math.min(i + 1, steps.length - 1))
  }

  const nextStep = steps[currentIndex + 1]

  return (
    <div className="focus-screen">
      <div className="focus-topbar">
        <button className="icon-btn" onClick={() => navigate('workout', { workoutId })} aria-label="Fechar modo foco">
          <CloseIcon />
        </button>
        <span className="focus-progress-text">
          {currentIndex + 1} / {steps.length}
        </span>
      </div>

      <div className="focus-dots">
        {Array.from({ length: step.totalInUnit }).map((_, i) => {
          const s = steps.find((st) => st.unitKey === step.unitKey && st.indexInUnit === i)
          let cls = 'focus-dot'
          if (s?.completed) cls += ' focus-dot--done'
          if (i === step.indexInUnit) cls += ' focus-dot--current'
          return <span key={i} className={cls} />
        })}
      </div>

      <div className="focus-body">
        {step.parentLabel && <div className="focus-parent">+ combo com {step.parentLabel}</div>}
        <div className="focus-name display" style={{ textTransform: 'none' }}>
          {step.label}
        </div>
        <div className="focus-scheme">
          Série {step.indexInUnit + 1} de {step.totalInUnit} · {step.reps} repetições
        </div>

        <div className="focus-weight">
          <input
            inputMode="decimal"
            type="text"
            placeholder="0"
            value={step.weight}
            onChange={(e) => updateSeries(step.unitKey, step.seriesIndex, { weight: e.target.value })}
          />
          <span>kg</span>
        </div>
      </div>

      <div className="focus-actions">
        {!step.completed && (
          <button className="focus-btn-complete" onClick={handleComplete}>
            ✓ Série concluída
          </button>
        )}
        {step.completed && allDone && (
          <button
            className="focus-btn-complete"
            onClick={() => {
              finishWorkout()
              navigate('completed', { workoutId })
            }}
          >
            🎉 Finalizar treino
          </button>
        )}
        {step.completed && !allDone && (
          <button className="focus-btn-complete" style={{ opacity: 0.55 }} onClick={goNext} disabled={currentIndex === steps.length - 1}>
            ✓ Série já concluída
          </button>
        )}
        <div className="focus-secondary-row">
          <button className="focus-btn-secondary" onClick={goPrev} disabled={currentIndex === 0}>
            ‹ Anterior
          </button>
          <button className="focus-btn-secondary" onClick={() => setResting(true)}>
            ⏱ Descanso
          </button>
          <button className="focus-btn-secondary" onClick={goNext} disabled={currentIndex === steps.length - 1}>
            Próxima ›
          </button>
        </div>
      </div>

      {resting && (
        <RestTimer
          duration={workout.defaultRest}
          nextLabel={nextStep ? nextStep.label : 'Fim do treino'}
          onDone={handleRestDone}
        />
      )}
    </div>
  )
}
