import React from 'react'
import { WORKOUTS } from '../data/workouts'
import { useApp } from '../context/AppContext'
import WorkoutCard from '../components/WorkoutCard'

export default function WorkoutsList() {
  const { navigate } = useApp()

  return (
    <div className="screen">
      <div className="display" style={{ fontSize: 26, marginBottom: 4 }}>
        Treinos
      </div>
      <div className="home-header__question" style={{ marginBottom: 20 }}>
        Protocolo completo — Team PG
      </div>
      <div className="workout-grid">
        {WORKOUTS.map((w) => (
          <WorkoutCard key={w.id} workout={w} onClick={() => navigate('workout', { workoutId: w.id })} />
        ))}
      </div>
    </div>
  )
}
