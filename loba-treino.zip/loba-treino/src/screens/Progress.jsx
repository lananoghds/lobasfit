import React from 'react'
import { useApp } from '../context/AppContext'
import { getWeeklyCount, getMonthlyCount, getCurrentStreak, getWeightProgressions } from '../lib/storage'

export default function Progress() {
  const { history } = useApp()

  const weekly = getWeeklyCount(history)
  const monthly = getMonthlyCount(history)
  const streak = getCurrentStreak(history)
  const progressions = getWeightProgressions(history).slice(0, 6)

  return (
    <div className="screen">
      <div className="display" style={{ fontSize: 26, marginBottom: 18 }}>
        Progresso
      </div>

      <div className="progress-grid">
        <div className="progress-card">
          <div className="progress-card__value">{weekly}</div>
          <div className="progress-card__label">Treinos na semana</div>
        </div>
        <div className="progress-card">
          <div className="progress-card__value">{monthly}</div>
          <div className="progress-card__label">Treinos no mês</div>
        </div>
        <div className="progress-card">
          <div className="progress-card__value">{streak}</div>
          <div className="progress-card__label">Sequência atual</div>
        </div>
        <div className="progress-card">
          <div className="progress-card__value">{history.length}</div>
          <div className="progress-card__label">Total registrado</div>
        </div>
      </div>

      <div className="section-title">Cargas em evolução</div>
      {progressions.length === 0 ? (
        <div className="empty-state" style={{ padding: '30px 20px' }}>
          Registre pesos em pelo menos dois treinos para ver sua evolução de carga aqui.
        </div>
      ) : (
        progressions.map((p) => (
          <div className="pr-row" key={p.label}>
            <span className="pr-row__name">{p.label}</span>
            <span className="pr-row__value">
              {p.first}kg → {p.last}kg (+{p.delta}kg)
            </span>
          </div>
        ))
      )}
    </div>
  )
}
