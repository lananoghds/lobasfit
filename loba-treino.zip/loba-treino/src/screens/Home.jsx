import React from 'react'
import { WORKOUTS } from '../data/workouts'
import { useApp } from '../context/AppContext'
import WorkoutCard from '../components/WorkoutCard'
import { ClawMark } from '../components/ClawMark'
import { getWeeklyCount, getCurrentStreak, getLastWorkout } from '../lib/storage'
import { formatDateShort, formatDuration } from '../lib/format'

export default function Home() {
  const { navigate, history } = useApp()

  const weeklyCount = getWeeklyCount(history)
  const streak = getCurrentStreak(history)
  const last = getLastWorkout(history)
  const recent = history.slice(0, 3)

  return (
    <div className="screen">
      <div className="brand-header">
        <span className="brand-header__word">LOBA</span>
        <span className="brand-header__line" />
      </div>

      <div className="home-header">
        <ClawMark className="brand-header__claw" />
        <div className="home-header__greeting">Olá, Lana 👋</div>
        <div className="home-header__question">Qual treino vamos fazer hoje?</div>
      </div>

      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-card__value">{weeklyCount}</div>
          <div className="stat-card__label">Na semana</div>
        </div>
        <div className="stat-card">
          <div className="stat-card__value">{streak}</div>
          <div className="stat-card__label">Sequência</div>
        </div>
        <div className="stat-card">
          <div className="stat-card__value">{history.length}</div>
          <div className="stat-card__label">Total</div>
        </div>
      </div>

      {last && (
        <button className="last-workout-card" onClick={() => navigate('history')} style={{ width: '100%', marginBottom: 8 }}>
          <span className="last-workout-card__emoji">{last.emoji}</span>
          <div>
            <div className="last-workout-card__title">Último treino: {last.workoutName}</div>
            <div className="last-workout-card__meta">
              {formatDateShort(last.date)} · {formatDuration(last.durationMs)} · {last.seriesConcluidas} séries
            </div>
          </div>
        </button>
      )}

      <div className="section-title">Treinos</div>
      <div className="workout-grid">
        {WORKOUTS.map((w) => (
          <WorkoutCard key={w.id} workout={w} onClick={() => navigate('workout', { workoutId: w.id })} />
        ))}
      </div>

      {recent.length > 0 && (
        <>
          <div className="section-title">Histórico recente</div>
          {recent.map((h, i) => (
            <div className="history-item" key={i}>
              <span className="history-item__emoji">{h.emoji}</span>
              <div style={{ flex: 1 }}>
                <div className="history-item__title">{h.workoutName}</div>
                <div className="history-item__meta">
                  {formatDuration(h.durationMs)} · {h.seriesConcluidas} séries
                </div>
              </div>
              <div className="history-item__date">{formatDateShort(h.date)}</div>
            </div>
          ))}
        </>
      )}
    </div>
  )
}
