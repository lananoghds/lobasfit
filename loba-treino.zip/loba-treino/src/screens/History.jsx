import React from 'react'
import { useApp } from '../context/AppContext'
import { formatDateShort, formatDuration, formatTimeOfDay } from '../lib/format'

export default function History() {
  const { history } = useApp()

  return (
    <div className="screen">
      <div className="display" style={{ fontSize: 26, marginBottom: 18 }}>
        Histórico
      </div>

      {history.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state__emoji">🗓️</div>
          Nenhum treino registrado ainda.
          <br />
          Comece um treino para ver seu histórico aqui.
        </div>
      ) : (
        history.map((h, i) => (
          <div className="history-item" key={i}>
            <span className="history-item__emoji">{h.emoji}</span>
            <div style={{ flex: 1 }}>
              <div className="history-item__title">{h.workoutName}</div>
              <div className="history-item__meta">
                {formatDuration(h.durationMs)} · {h.seriesConcluidas} séries concluídas
              </div>
            </div>
            <div className="history-item__date">
              {formatDateShort(h.date)}
              <br />
              {formatTimeOfDay(h.date)}
            </div>
          </div>
        ))
      )}
    </div>
  )
}
