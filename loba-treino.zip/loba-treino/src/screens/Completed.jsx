import React from 'react'
import { useApp } from '../context/AppContext'
import { getLastWorkout } from '../lib/storage'
import { formatDuration } from '../lib/format'
import { ClawMark } from '../components/ClawMark'

export default function Completed() {
  const { navigate, history } = useApp()
  const last = getLastWorkout(history)

  if (!last) {
    navigate('home')
    return null
  }

  const exerciseCount = last.exercises.filter((e) => e.series.some((s) => s.completed)).length

  return (
    <div className="completed-screen">
      <div style={{ position: 'relative' }}>
        <ClawMark style={{ position: 'absolute', top: -30, left: '50%', transform: 'translateX(-50%)', opacity: 0.7 }} />
        <div className="completed-emoji">🎉</div>
      </div>
      <div className="display completed-title">Treino concluído</div>
      <div className="completed-sub">{last.workoutName} · muito bem, Lana!</div>

      <div className="completed-stats">
        <div className="stat-card">
          <div className="stat-card__value">{formatDuration(last.durationMs)}</div>
          <div className="stat-card__label">Duração</div>
        </div>
        <div className="stat-card">
          <div className="stat-card__value">{exerciseCount}</div>
          <div className="stat-card__label">Exercícios</div>
        </div>
        <div className="stat-card">
          <div className="stat-card__value">{last.seriesConcluidas}</div>
          <div className="stat-card__label">Séries</div>
        </div>
      </div>

      <button className="completed-cta" onClick={() => navigate('home')}>
        Voltar ao início
      </button>
    </div>
  )
}
