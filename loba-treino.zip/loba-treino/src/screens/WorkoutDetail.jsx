import React, { useEffect, useState } from 'react'
import { getWorkoutById } from '../data/workouts'
import { useApp } from '../context/AppContext'
import ExerciseCard from '../components/ExerciseCard'
import RestTimer from '../components/RestTimer'

function BackIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="m15 18-6-6 6-6" />
    </svg>
  )
}

export default function WorkoutDetail({ workoutId }) {
  const { navigate, session, startWorkout, finishWorkout } = useApp()
  const [resting, setResting] = useState(false)
  const workout = getWorkoutById(workoutId)

  useEffect(() => {
    if (!session || session.workoutId !== workoutId) {
      startWorkout(workoutId)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workoutId])

  if (!workout) return null
  if (!session || session.workoutId !== workoutId) return null

  const unitFor = (key) => session.units.find((u) => u.key === key)

  const totalSeries = session.units.reduce((acc, u) => acc + u.series.length, 0)
  const doneSeries = session.units.reduce((acc, u) => acc + u.series.filter((s) => s.completed).length, 0)
  const hasProgress = doneSeries > 0

  function handleFinish() {
    finishWorkout()
    navigate('completed', { workoutId })
  }

  return (
    <div className="screen">
      <div className="workout-header">
        <button className="icon-btn" onClick={() => navigate('home')} aria-label="Voltar">
          <BackIcon />
        </button>
        <div className="display workout-header__title">{workout.name}</div>
      </div>

      {workout.note && <div className="workout-note">{workout.note}</div>}
      {workout.extra && <div className="workout-extra">🏃 {workout.extra}</div>}

      {workout.exercises.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state__emoji">📋</div>
          Este grupo não tem exercícios detalhados na ficha.
          <br />
          Siga a orientação: <strong>{workout.note}</strong>
        </div>
      ) : (
        <>
          <button className="cta-start" onClick={() => navigate('focus', { workoutId })}>
            ▶ Iniciar treino
          </button>

          <div className="section-title">
            {doneSeries} de {totalSeries} séries concluídas
          </div>

          {workout.exercises.map((ex, i) => (
            <ExerciseCard
              key={ex.id}
              exercise={ex}
              index={i}
              unitFor={unitFor}
              onSeriesCompleted={() => setResting(true)}
            />
          ))}

          {hasProgress && (
            <button className="completed-cta" style={{ marginTop: 10 }} onClick={handleFinish}>
              Finalizar treino
            </button>
          )}
        </>
      )}

      {resting && (
        <RestTimer duration={workout.defaultRest} onDone={() => setResting(false)} />
      )}
    </div>
  )
}
