// Dados extraídos fielmente do "Protocolo de Treino - Lana" (Team PG / Pedro Gouveia).
// Nenhum exercício foi inventado ou alterado — apenas organizado em formato de app.

export const WORKOUTS = [
  {
    id: 'quadriceps',
    name: 'Quadríceps',
    emoji: '🦵',
    note: 'Tempo de descanso: 1 min entre séries',
    defaultRest: 60,
    extra: '7 min de passada sem parar (cardio ao final do treino)',
    exercises: [
      {
        id: 'q1',
        name: 'Agachamento livre, máquina ou Smith',
        sets: 4,
        reps: '15',
      },
      {
        id: 'q2',
        name: 'Leg Press',
        sets: 3,
        reps: '20',
        combo: { name: 'Agachamento taça', sets: 3, reps: '15' },
      },
      {
        id: 'q3',
        name: 'Cadeira extensora',
        sets: 4,
        reps: '12',
        combo: { name: 'Cadeirinha isométrica', sets: 1, reps: '1 min (isometria)' },
      },
      {
        id: 'q4',
        name: 'Cadeira adutora',
        sets: 3,
        reps: '12',
      },
    ],
  },
  {
    id: 'costas-biceps',
    name: 'Costas + Bíceps',
    emoji: '🏋️',
    note: 'Conjugar com escada',
    defaultRest: 60,
    exercises: [
      {
        id: 'cb1',
        name: 'Puxador aberto com barra',
        sets: 3,
        reps: '15',
        combo: { name: 'Rosca punho com halter', sets: 3, reps: '12' },
      },
      {
        id: 'cb2',
        name: 'Remada cavalinho com triângulo',
        sets: 3,
        reps: '15',
        combo: { name: 'Rosca martelo', sets: 3, reps: '12' },
      },
      {
        id: 'cb3',
        name: 'Remada curvada com barra',
        sets: 4,
        reps: '10',
        combo: { name: 'Rosca 21', sets: 3, reps: '21' },
      },
      {
        id: 'cb4',
        name: 'Voador inverso',
        sets: 3,
        reps: '15',
      },
    ],
  },
  {
    id: 'posterior',
    name: 'Posterior',
    emoji: '🍑',
    note: '',
    defaultRest: 60,
    exercises: [
      {
        id: 'p1',
        name: 'Mesa flexora',
        sets: 4,
        reps: '12',
        combo: { name: 'Agachamento sumo', sets: 4, reps: '15' },
      },
      {
        id: 'p2',
        name: 'Flexora sentada',
        sets: 3,
        reps: '12',
        combo: { name: 'Stiff', sets: 3, reps: '10' },
      },
      {
        id: 'p3',
        name: 'Elevação pélvica',
        sets: 5,
        reps: '10',
      },
      {
        id: 'p4',
        name: 'Cadeira abdutora',
        sets: 4,
        reps: '12-15',
      },
      {
        id: 'p5',
        name: 'Panturrilha em pé',
        sets: 3,
        reps: '30',
      },
    ],
  },
  {
    id: 'peito-ombro-triceps',
    name: 'Peito + Ombro + Tríceps',
    emoji: '💪',
    note: 'Conjugar com escada',
    defaultRest: 60,
    exercises: [
      {
        id: 'pot1',
        name: 'Supino inclinado',
        sets: 3,
        reps: '12',
        combo: { name: 'Crucifixo inclinado', sets: 3, reps: '12' },
      },
      {
        id: 'pot2',
        name: 'Desenvolvimento com halter',
        sets: 3,
        reps: '15',
        combo: { name: 'Elevação frontal com barra W', sets: 3, reps: '15' },
      },
      {
        id: 'pot3',
        name: 'Elevação lateral',
        sets: 4,
        reps: '20',
        combo: { name: 'Remada alta', sets: 4, reps: '10' },
      },
      {
        id: 'pot4',
        name: 'Tríceps corda',
        sets: 3,
        reps: '15',
        combo: { name: 'Francês com halter', sets: 3, reps: '12' },
      },
      {
        id: 'pot5',
        name: 'Tríceps banco',
        sets: 3,
        reps: '15',
      },
    ],
  },
  {
    id: 'gluteo',
    name: 'Glúteo',
    emoji: '🍑',
    note: '',
    defaultRest: 60,
    exercises: [
      {
        id: 'g1',
        name: 'Cadeira abdutora',
        sets: 3,
        reps: '2 min executando',
      },
      {
        id: 'g2',
        name: 'Elevação pélvica',
        sets: 4,
        reps: '10',
      },
      {
        id: 'g3',
        name: 'Agachamento sumo no Smith ou halter',
        sets: 4,
        reps: '10',
      },
      {
        id: 'g4',
        name: 'Flexora em pé',
        sets: 4,
        reps: '15',
      },
      {
        id: 'g5',
        name: 'Panturrilha sentada',
        sets: 4,
        reps: '15',
      },
    ],
  },
  {
    id: 'abdominal',
    name: 'Abdominal',
    emoji: '🔥',
    note: 'Dia sim e dia não',
    defaultRest: 45,
    exercises: [],
  },
  {
    id: 'panturrilha',
    name: 'Panturrilha',
    emoji: '⚡',
    note: 'Dia sim e dia não — exercícios de panturrilha já aparecem embutidos nos treinos de Posterior e Glúteo',
    defaultRest: 45,
    exercises: [],
  },
]

export function getWorkoutById(id) {
  return WORKOUTS.find((w) => w.id === id)
}

// Retorna a lista "achatada" de séries de um exercício (considerando combo)
// usada para navegação passo a passo no Modo Foco.
export function buildExerciseSteps(exercise) {
  const steps = []
  for (let i = 0; i < exercise.sets; i++) {
    steps.push({ part: 'main', setIndex: i, name: exercise.name, reps: exercise.reps })
  }
  if (exercise.combo) {
    for (let i = 0; i < exercise.combo.sets; i++) {
      steps.push({ part: 'combo', setIndex: i, name: exercise.combo.name, reps: exercise.combo.reps })
    }
  }
  return steps
}
